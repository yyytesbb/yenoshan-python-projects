# I-Love-You-by-Python-Code
Say I Love You to your beloved person using python code. Here we've used the python turtle module and pygame module to develop the program.

Requirements: turtle and pygame modules.
